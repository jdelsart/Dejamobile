package nl.jaapcoomans.demo.mockserver.gameservice.domain;

public interface CodeGenerator {
    Code generateCode();
}
