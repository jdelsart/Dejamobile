package nl.jaapcoomans.demo.mockserver.gameservice.domain;

public enum ColoredPin {
    BLACK,
    BLUE,
    BROWN,
    GREEN,
    ORANGE,
    RED,
    WHITE,
    YELLOW
}
