package nl.jaapcoomans.demo.mockserver.gameservice.domain;

public enum GameStatus {
    WON, LOST, IN_PROGRESS;
}
