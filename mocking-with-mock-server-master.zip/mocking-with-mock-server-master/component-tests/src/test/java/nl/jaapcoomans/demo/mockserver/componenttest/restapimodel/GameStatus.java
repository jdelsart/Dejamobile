package nl.jaapcoomans.demo.mockserver.componenttest.restapimodel;

public enum GameStatus {
    WON, LOST, IN_PROGRESS
}
